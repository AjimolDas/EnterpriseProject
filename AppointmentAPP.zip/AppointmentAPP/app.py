from flask import Flask, render_template,request,redirect,url_for
from bson import ObjectId
from pymongo import MongoClient
import os
app = Flask(__name__)

title = "Application with Flask and MongoDB"
heading = "Appointment List with Flask and MongoDB"

client = MongoClient("mongodb://127.0.0.1:27017")
db = client.salsesmongo
todos = db.todo

def redirect_url():
    return request.args.get('next') or \
        request.referrer or \
        url_for('index')

@app.route("/list")
def lists ():
    #Display the all Appointment
    todos_l = todos.find()
    a1="active"
    return render_template('index.html',a1=a1,todos=todos_l,t=title,h=heading)

@app.route("/action", methods=['POST'])
def action ():
    #Adding a Appointment
    name=request.values.get("name")
    sname=request.values.get("sname")
    desc=request.values.get("desc")
    date=request.values.get("date")
    pr=request.values.get("pr")
    todos.insert({ "name":name, "sname":sname, "desc":desc, "date":date, "pr":pr})
    return redirect("/list")

@app.route("/remove")
def remove ():
    #Deleting a appointment with various references
    key=request.values.get("_id")
    todos.remove({"_id":ObjectId(key)})
    return redirect("/list")

@app.route("/update")
def update ():
    id=request.values.get("_id")
    task=todos.find({"_id":ObjectId(id)})
    return render_template('update.html',tasks=task,h=heading,t=title)

@app.route("/action3", methods=['POST'])
def action3 ():
    #Updating a Appointment with various references
    name=request.values.get("name")
    sname=request.values.get("sname")
    desc=request.values.get("desc")
    date=request.values.get("date")
    pr=request.values.get("pr")
    id=request.values.get("_id")
    todos.update({"_id":ObjectId(id)}, {'$set':{ "name":name, "sname":sname, "desc":desc, "date":date, "pr":pr }})
    return redirect("/list")

@app.route("/search", methods=['GET'])
def search():
    #Searching a Appointment with various references
    key=request.values.get("key")
    refer=request.values.get("refer")
    if(key=="_id"):
        todos_l = todos.find({refer:ObjectId(key)})
    else:
        todos_l = todos.find({refer:key})
    return render_template('searchlist.html',todos=todos_l,t=title,h=heading)

if __name__ == "__main__":
    app.run()